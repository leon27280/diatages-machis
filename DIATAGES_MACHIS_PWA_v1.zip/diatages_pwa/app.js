const fields=['title','unit','dt','place','recipients','refs','situation','mission','execution','admin','command','annexes'];
function v(id){return document.getElementById(id).value.trim()}
function set(id,val){document.getElementById(id).value=val||''}
function build(){return `ΤΙΤΛΟΣ: ${v('title')}\nΜΟΝΑΔΑ: ${v('unit')}\nΗΜ/ΝΙΑ-ΩΡΑ: ${v('dt')}\nΤΟΠΟΣ: ${v('place')}\n\nΑΠΟΔΕΚΤΕΣ\n${v('recipients')}\n\nΧΑΡΤΕΣ / ΑΝΑΦΟΡΕΣ\n${v('refs')}\n\n1. ΚΑΤΑΣΤΑΣΗ\n${v('situation')}\n\n2. ΑΠΟΣΤΟΛΗ\n${v('mission')}\n\n3. ΕΚΤΕΛΕΣΗ\n${v('execution')}\n\n4. ΔΙΟΙΚΗΤΙΚΗ ΜΕΡΙΜΝΑ\n${v('admin')}\n\n5. ΔΙΟΙΚΗΣΗ ΚΑΙ ΔΙΑΒΙΒΑΣΕΙΣ\n${v('command')}\n\nΠΑΡΑΡΤΗΜΑΤΑ / ΣΗΜΕΙΩΣΕΙΣ\n${v('annexes')}`}
function update(){document.getElementById('preview').textContent=build(); const must=['title','unit','dt','situation','mission','execution','admin','command']; document.getElementById('checks').innerHTML=must.map(id=>`<div class="${v(id)?'ok':'bad'}">${v(id)?'✓':'✗'} ${label(id)}</div>`).join('')}
function label(id){return ({title:'Τίτλος',unit:'Μονάδα',dt:'Ημερομηνία/ώρα',situation:'Κατάσταση',mission:'Αποστολή',execution:'Εκτέλεση',admin:'Διοικητική μέριμνα',command:'Διοίκηση/Διαβιβάσεις'})[id]||id}
function data(){let o={}; fields.forEach(f=>o[f]=v(f)); return o}
function saveDraft(){localStorage.setItem('diatagi_draft',JSON.stringify(data())); msg('Αποθηκεύτηκε στη συσκευή.');}
function loadDraft(){let o=JSON.parse(localStorage.getItem('diatagi_draft')||'{}'); fields.forEach(f=>set(f,o[f])); update(); msg('Φορτώθηκε.');}
function clearAll(){if(confirm('Να καθαριστούν όλα τα πεδία;')){fields.forEach(f=>set(f,'')); update();}}
function exportTxt(){const blob=new Blob([build()],{type:'text/plain;charset=utf-8'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=(v('title')||'diatagi')+'.txt'; a.click(); URL.revokeObjectURL(a.href);}
function msg(t){document.getElementById('status').textContent=t; setTimeout(()=>document.getElementById('status').textContent='',3000)}
fields.forEach(f=>document.getElementById(f).addEventListener('input',update));
if('serviceWorker' in navigator){navigator.serviceWorker.register('./sw.js').catch(()=>{});} loadDraft(); update();
